insert into user (userid,upassword,uname) values ('ashish','ashish','ashish');
insert into user (userid,upassword,uname) values ('abhijeet','abhijeet','abhijeet');