package com.web.project.truyumwebportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.project.truyumwebportal.feignproxy.PortfolioDetailsFeignClient;

@Service
public class WebService {
	
	@Autowired
	private PortfolioDetailsFeignClient portFolioDetailsFeignClient;
	
	
}
