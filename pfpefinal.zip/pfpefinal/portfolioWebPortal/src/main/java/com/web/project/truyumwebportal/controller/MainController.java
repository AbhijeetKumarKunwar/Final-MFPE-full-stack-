package com.web.project.truyumwebportal.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.web.project.truyumwebportal.entity.AssetSaleResponse;
import com.web.project.truyumwebportal.entity.MutualFundDetails;
import com.web.project.truyumwebportal.entity.PortFolioDetails;
import com.web.project.truyumwebportal.entity.StockDetails;
import com.web.project.truyumwebportal.entity.UserLoginCredential;
import com.web.project.truyumwebportal.feignproxy.AuthenticationFeign;
import com.web.project.truyumwebportal.feignproxy.PortfolioDetailsFeignClient;

@Controller
public class MainController {

	@Autowired
	private AuthenticationFeign authFeign;

	@Autowired
	private PortfolioDetailsFeignClient portfolioDetailsFeignClient;

	@RequestMapping(path = "/login", method = RequestMethod.GET)
	public ModelAndView getLogin() {
		return new ModelAndView("login");
	}

	@RequestMapping(path = "/login", method = RequestMethod.POST)
	public ModelAndView postLogin(@ModelAttribute UserLoginCredential user, HttpServletRequest request) {

		// System.out.println(user.getAuthToken());
		// System.out.println(user.getUname());
		// System.out.println(user.getUpassword());
		UserLoginCredential userToken = null;

		try {
			userToken = authFeign.login(user);
		} catch (Exception e) {
			ModelAndView model = new ModelAndView("login");
			model.addObject("loginError", "UserId or Password is incorrect.. plz try again");
			return model;
		}

		request.getSession().setAttribute("token", "Bearer " + userToken.getAuthToken());
		request.getSession().setAttribute("name", userToken.getUserid());

		System.out.println("PostLoginToken:" + request.getSession().getAttribute("token"));

		PortFolioDetails portFolioDetail = portfolioDetailsFeignClient
				.getPortFolio("Bearer " + userToken.getAuthToken(), userToken.getUserid());

		List<MutualFundDetails> mutualFundList = portFolioDetail.getMutualFundList();
		List<StockDetails> stockList = portFolioDetail.getStockList();

		double totalNetWorth = portfolioDetailsFeignClient.calculateNetworth("Bearer " + userToken.getAuthToken(),
				userToken.getUserid());

		ModelAndView modelAndView = new ModelAndView("portfolio-Details");
		for(StockDetails s: stockList) {
			System.out.println(s.getStockCount()+""+s.getStockName());
		}
		modelAndView.addObject("stockList", stockList);
		modelAndView.addObject("mutualFundList", mutualFundList);
		modelAndView.addObject("name", userToken.getUserid().toUpperCase());
		modelAndView.addObject("totalNetWorth", totalNetWorth);
		return modelAndView;
	}

	@RequestMapping(path = "/sellStocks", method = RequestMethod.GET)
	public ModelAndView getSellStock(HttpServletRequest request) {
		ModelAndView model = new ModelAndView("sellstocks");
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		if (token != null) {
			PortFolioDetails portFolioDetail = portfolioDetailsFeignClient.getPortFolio(token, name);

			List<StockDetails> stockList = portFolioDetail.getStockList();
			model.addObject("stockList", stockList);
			// System.out.println("GetSellStockTo:" + token);
			return model;
		}
		ModelAndView loginModel = new ModelAndView("login");
		loginModel.addObject("loginError", "Your token got expired..please login again");
		return loginModel;
	}

	@RequestMapping(path = "/sellParticularStocks", method = RequestMethod.GET)
	public ModelAndView sellStock(@RequestParam String stockName, HttpServletRequest request) {

		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");

		ModelAndView model = new ModelAndView("sell");

		if (token != null) {

			PortFolioDetails portFolioDetail = portfolioDetailsFeignClient.getPortFolio(token, name);
			List<StockDetails> stockList = portFolioDetail.getStockList();
			for (StockDetails stockDetail : stockList) {
				if (stockDetail.getStockName().equals(stockName)) {
					model.addObject("stockId", stockDetail.getStockId());
					model.addObject("stockName", stockName);
					model.addObject("stockCount", stockDetail.getStockCount());
					return model;
				}
			}
		}

		ModelAndView loginModel = new ModelAndView("login");
		loginModel.addObject("loginError", "Your token got expired..please login again");
		return loginModel;

	}

	@RequestMapping(path = "/sellParticularStocks", method = RequestMethod.POST)
	public ModelAndView sellStockPost(HttpServletRequest request) {

		ModelAndView m = new ModelAndView("successsell");

		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		int stockId = Integer.parseInt(request.getParameter("stockId"));
		String stockName = request.getParameter("stockName");
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int actualCount = Integer.parseInt(request.getParameter("stockCount"));
		// System.out.println(quantity + " " + actualCount);

		if (token != null) {

			/*
			 * if (quantity > actualCount) { ModelAndView model = new
			 * ModelAndView("sellstocks"); model.addObject("error",
			 * "Plzz be in your limits.."); return model; }
			 */

			List<StockDetails> stockList = new ArrayList<StockDetails>();
			StockDetails stockDetails = new StockDetails(stockId, stockName, quantity, null);
			stockList.add(stockDetails);

			PortFolioDetails portFolioDetail = new PortFolioDetails(name, name, stockList,
					new ArrayList<MutualFundDetails>());

			AssetSaleResponse sellDetails = portfolioDetailsFeignClient.sell(token, portFolioDetail);
			double totalNetWorth = portfolioDetailsFeignClient.calculateNetworth(token, name);

			m.addObject("repsonse", sellDetails.isSaleStatus());
			m.addObject("amount", sellDetails.getNetWorth());
			m.addObject("leftAmount", totalNetWorth);
			return m;
		}

		ModelAndView loginModel = new ModelAndView("login");
		loginModel.addObject("loginError", "Your token got expired..please login again");
		return loginModel;

	}

	@RequestMapping(path = "/sellMutualFunds", method = RequestMethod.GET)
	public ModelAndView getSetMutualFund(HttpServletRequest request) {
		ModelAndView model = new ModelAndView("sellmutualfunds");
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		if (token != null) {
			PortFolioDetails portFolioDetail = portfolioDetailsFeignClient.getPortFolio(token, name);

			List<MutualFundDetails> mutualFundList = portFolioDetail.getMutualFundList();
			model.addObject("mutualFundList", mutualFundList);
			// System.out.println("GetSellStockTo:" + token);
			return model;
		}
		return new ModelAndView("login");
	}

	@RequestMapping(path = "/sellParticularMutualFunds", method = RequestMethod.GET)
	public ModelAndView sellMutualFund(@RequestParam String mutualFundName, HttpServletRequest request) {

		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");

		ModelAndView model = new ModelAndView("sellmutual");

		if (token != null) {

			PortFolioDetails portFolioDetail = portfolioDetailsFeignClient.getPortFolio(token, name);
			List<MutualFundDetails> mutualFundList = portFolioDetail.getMutualFundList();
			for (MutualFundDetails mutualDetail : mutualFundList) {
				if (mutualDetail.getMutualFundName().equals(mutualFundName)) {
					model.addObject("mutualId", mutualDetail.getMutualId());
					model.addObject("mutualFundName", mutualFundName);
					model.addObject("mutualFundUnits", mutualDetail.getMutualFundUnits());
					return model;
				}
			}
		}

		ModelAndView loginModel = new ModelAndView("login");
		loginModel.addObject("loginError", "Your token got expired..please login again");
		return loginModel;
	}

	@RequestMapping(path = "/sellParticularMutualFunds", method = RequestMethod.POST)
	public ModelAndView sellMutualFundPost(HttpServletRequest request) {

		ModelAndView m = new ModelAndView("successsell");

		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		int mutualId = Integer.parseInt(request.getParameter("mutualId"));
		String mutualFundName = request.getParameter("mutualFundName");
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int actualCount = Integer.parseInt(request.getParameter("mutualFundUnits"));
		// System.out.println(quantity + " " + actualCount);

		if (token != null) {

			/*
			 * if (quantity > actualCount) { ModelAndView model = new
			 * ModelAndView("sellstocks"); model.addObject("error",
			 * "Plzz be in your limits.."); return model; }
			 */

			List<MutualFundDetails> mutualList = new ArrayList<MutualFundDetails>();
			MutualFundDetails mutualDetails = new MutualFundDetails(mutualId, mutualFundName, quantity, null);
			mutualList.add(mutualDetails);

			PortFolioDetails portFolioDetail = new PortFolioDetails(name, name, new ArrayList<StockDetails>(),
					mutualList);

			AssetSaleResponse sellDetails = portfolioDetailsFeignClient.sell(token, portFolioDetail);
			double totalNetWorth = portfolioDetailsFeignClient.calculateNetworth(token, name);

			m.addObject("repsonse", sellDetails.isSaleStatus());
			m.addObject("amount", sellDetails.getNetWorth());
			m.addObject("leftAmount", totalNetWorth);
			return m;
		}

		ModelAndView loginModel = new ModelAndView("login");
		loginModel.addObject("loginError", "Your token got expired..please login again");
		return loginModel;

	}

	@RequestMapping(path = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpSession session) {
		session.setAttribute("token", null);
		session.setAttribute("name", null);
		session.invalidate();
		ModelAndView modelAndView = new ModelAndView("login");
		return modelAndView;
	}

}
