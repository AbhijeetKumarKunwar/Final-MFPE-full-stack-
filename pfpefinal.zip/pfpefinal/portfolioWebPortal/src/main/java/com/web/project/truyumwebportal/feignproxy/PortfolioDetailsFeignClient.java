package com.web.project.truyumwebportal.feignproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.web.project.truyumwebportal.entity.AssetSaleResponse;
import com.web.project.truyumwebportal.entity.PortFolioDetails;

@FeignClient(name = "calculateNetworth-service", url = "localhost:8011")
public interface PortfolioDetailsFeignClient {

	@RequestMapping(path = "/networth/calculateNetworth/{protofolioId}", method = RequestMethod.GET)
	public double calculateNetworth(@RequestHeader(name = "Authorization") String token,
			@PathVariable("protofolioId") String portFolioId);

	@RequestMapping(path = "/networth/sellStock", method = RequestMethod.POST)
	public AssetSaleResponse sell(@RequestHeader(name = "Authorization") String token, @RequestBody PortFolioDetails portFolio);

	@RequestMapping(path = "/networth/getPortFolio/{name}", method = RequestMethod.GET)
	public PortFolioDetails getPortFolio(@RequestHeader(name = "Authorization") String token,@PathVariable("name") String name);
}
