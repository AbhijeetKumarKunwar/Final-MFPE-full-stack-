package com.web.project.truyumwebportal.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MutualFundDetails {

	private int mutualId;

	private String mutualFundName;

	private int mutualFundUnits;

	private PortFolioDetails portFolio;

}
