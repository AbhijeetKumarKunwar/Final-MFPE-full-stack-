package com.web.project.truyumwebportal.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class StockDetails {

	private int stockId;
	private String stockName;
	private int stockCount;
	private PortFolioDetails portFolio;

}