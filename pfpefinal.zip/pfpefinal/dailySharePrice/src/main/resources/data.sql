INSERT INTO stock_details (stock_id,stock_name,stock_value) VALUES
  (1,'Apple',71637.248);
  INSERT INTO stock_details (stock_id,stock_name,stock_value) VALUES (2,'JPMorgan Chase',28146.4);
  INSERT INTO stock_details (stock_id,stock_name,stock_value) VALUES (3,'Johnson and Johnson',25506.976);
  INSERT INTO stock_details (stock_id,stock_name,stock_value) VALUES (4,'Walt Disney',18953.152);