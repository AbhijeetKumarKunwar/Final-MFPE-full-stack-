package com.cognizant.mfpe.dailySharePrice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name="stock_details")
public class DailyStockDetails {
	
	@Id
	@Column(name = "stock_id")
	private int stockId;
	@Column(name = "stock_name", length = 20)
	private String stockName;
	@Column(name = "stock_value")
	private double stockValue;
	
	
}
