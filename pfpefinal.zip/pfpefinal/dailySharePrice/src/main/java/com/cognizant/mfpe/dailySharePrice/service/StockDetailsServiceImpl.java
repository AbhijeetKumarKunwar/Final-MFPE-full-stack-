package com.cognizant.mfpe.dailySharePrice.service;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.mfpe.dailySharePrice.model.DailyStockDetails;
import com.cognizant.mfpe.dailySharePrice.repository.StockRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StockDetailsServiceImpl implements StockDetailsService {
	
	@Autowired
	StockRepository stockRepository;

	@Override
	@Transactional
	public DailyStockDetails findByStockName(String stockName) {
		log.info("findByStockName() method called");
		return stockRepository.findByStockName(stockName);
	}
	
}
