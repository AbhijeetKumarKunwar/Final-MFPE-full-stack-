package com.cognizant.mfpe.dailySharePrice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.mfpe.dailySharePrice.client.AuthClient;
import com.cognizant.mfpe.dailySharePrice.exception.StockNotFoundException;
import com.cognizant.mfpe.dailySharePrice.model.AuthResponse;
import com.cognizant.mfpe.dailySharePrice.model.DailyStockDetails;
import com.cognizant.mfpe.dailySharePrice.service.StockDetailsService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
//@RequestMapping(path = "/dailySharePrice")
public class DailySharePriceController {

	@Autowired
	private StockDetailsService stockDetailsService;

	@Autowired
	private AuthClient authclient;

	@GetMapping(path = "/dailySharePrice/{name}")
	public ResponseEntity<?> dailySharePrice(@RequestHeader(name = "Authorization") String token, @PathVariable("name") String stockName) {
		log.info("AuthClient: VerifyToken method called");
		AuthResponse authResponse = authclient.getValidity(token);
		if (authResponse.isValid()) {
			log.info("AuthClient:Authentication validated");
			DailyStockDetails stock = stockDetailsService.findByStockName(stockName);
			if(stock != null)
				return new ResponseEntity<>(stock, HttpStatus.OK);
			else{
				throw new StockNotFoundException("This stock does not exist");
			}
		} 
		else {
			log.error("AuthClient: Authentication failed");
			return new ResponseEntity<>("You are not LoggedIn", HttpStatus.FORBIDDEN);
		}
	}
}
