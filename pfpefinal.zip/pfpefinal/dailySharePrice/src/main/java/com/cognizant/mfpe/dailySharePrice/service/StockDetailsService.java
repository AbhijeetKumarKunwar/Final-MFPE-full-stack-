package com.cognizant.mfpe.dailySharePrice.service;

import com.cognizant.mfpe.dailySharePrice.model.DailyStockDetails;

public interface StockDetailsService {
	public DailyStockDetails findByStockName(String stockName);
}

