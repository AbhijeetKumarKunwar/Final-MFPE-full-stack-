package com.cognizant.mfpe.dailySharePrice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.mfpe.dailySharePrice.model.DailyStockDetails;

@Repository
public interface StockRepository extends JpaRepository<DailyStockDetails, Integer>{
	DailyStockDetails findByStockName(String stockName);
}

