package com.cognizant.mfpe.dailySharePrice.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class ModelTest {

	@Test
	public void gettersetterAuthResponseTest() {
		AuthResponse response = new AuthResponse();
		response.setName("test");
		response.setUid("testuid");
		response.setValid(true);

		assertEquals("test", response.getName());
		assertEquals("testuid", response.getUid());
		assertEquals(true, response.isValid());
	}

	@Test
	public void constructerAuthResponseTest() {
		AuthResponse responseNoArg = new AuthResponse();
		assertNotNull(responseNoArg);
		AuthResponse responseAllArg = new AuthResponse("testuid", "test", true);
		assertNotNull(responseAllArg);
	}
	
	@Test
	public void gettersetterStockDetailsTest() {
		DailyStockDetails stockDetails = new DailyStockDetails();
		stockDetails.setStockId(1);
		stockDetails.setStockName("Apple");
		stockDetails.setStockValue(71637.248);

		assertEquals("Apple", stockDetails.getStockName());
		assertEquals(1, stockDetails.getStockId());
		assertEquals(71637.248, stockDetails.getStockValue(),0);
	}
	
	
	@Test
	public void constructerStockDetailsTest() {
		DailyStockDetails stockDetailsNoArg = new DailyStockDetails();
		assertNotNull(stockDetailsNoArg);
		DailyStockDetails stockDetailsAllArg = new DailyStockDetails(1, "Apple", 71637.248);
		assertNotNull(stockDetailsAllArg);
	}

	@Test
	public void toStringStockDetailsTest() {
		DailyStockDetails stockDetails = new DailyStockDetails();
		stockDetails.setStockId(1);
		stockDetails.setStockName("Apple");
		stockDetails.setStockValue(71637.248);

		assertTrue(stockDetails.toString().startsWith(DailyStockDetails.class.getSimpleName()));
		assertTrue(stockDetails.toString().endsWith("(stockId=1, stockName=Apple, stockValue=71637.248)"));
	}
	
}

