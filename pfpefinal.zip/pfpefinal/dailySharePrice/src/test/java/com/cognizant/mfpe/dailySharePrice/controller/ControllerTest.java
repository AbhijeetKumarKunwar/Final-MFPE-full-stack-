package com.cognizant.mfpe.dailySharePrice.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.jdbc.Expectation;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cognizant.mfpe.dailySharePrice.client.AuthClient;
import com.cognizant.mfpe.dailySharePrice.exception.StockNotFoundException;
import com.cognizant.mfpe.dailySharePrice.model.AuthResponse;
import com.cognizant.mfpe.dailySharePrice.model.DailyStockDetails;

import com.cognizant.mfpe.dailySharePrice.repository.StockRepository;
import com.cognizant.mfpe.dailySharePrice.service.StockDetailsService;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class ControllerTest {
	
	@Mock
	StockDetailsService service;

	@InjectMocks
	DailySharePriceController controller;

	@Mock
	AuthClient authClient;

	@Mock
	StockRepository stockDetailsRepository;

	@Mock
	DailyStockDetails stockDetails;
	
	AuthResponse authResponse;
	List<DailyStockDetails> stockDetailsDetailsList;
	String token="admin";
	String stockDetailsName="Apple";
	boolean isValid = true;

	
	
	@Before
	public void setUp() {
		authResponse = new AuthResponse("userid", "username", true);
		stockDetailsDetailsList= new ArrayList<DailyStockDetails>();
		stockDetailsDetailsList.add(new DailyStockDetails(1, "Apple", 71637.248));
		stockDetailsDetailsList.add(new DailyStockDetails(2, "HDFC", 399.12));
	}

	@Test
	public void getallTest() {
		when(authClient.getValidity("token")).thenReturn(authResponse);
		//when(authResponse.isValid()).thenReturn(true);
		
		assertNotNull(authResponse.isValid());
		when(service.findByStockName("Apple")).thenReturn(new DailyStockDetails(1, "Apple", 71637.248));
		assertNotNull(stockDetails);
		ResponseEntity<?>stockDetails = controller.dailySharePrice("token","Apple");
		assertEquals(200, stockDetails.getStatusCodeValue());
		assertNotNull(stockDetails);
	}
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	@Test
	public void getallNotFoundTest() {
		when(authClient.getValidity("token")).thenReturn(authResponse);
		assertNotNull(authResponse.isValid());
		when(service.findByStockName("Apple")).thenReturn(null);
		thrown.expect(StockNotFoundException.class);
		ResponseEntity<?> stockDetails = controller.dailySharePrice("token", "");
		assertEquals(403, stockDetails.getStatusCodeValue());

		}

	

	@Test
	public void getallFail() {
		when(authClient.getValidity("token")).thenReturn(new AuthResponse("", "", false));
		when(service.findByStockName("Apple")).thenReturn(new DailyStockDetails(1, "Apple", 71637.248));
		ResponseEntity<?> stockDetails = controller.dailySharePrice("token", "Apple");
		assertEquals(403, stockDetails.getStatusCodeValue());
	}
}