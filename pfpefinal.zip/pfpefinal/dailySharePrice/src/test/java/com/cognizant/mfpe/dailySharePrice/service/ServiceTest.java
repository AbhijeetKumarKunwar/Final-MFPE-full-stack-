package com.cognizant.mfpe.dailySharePrice.service;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cognizant.mfpe.dailySharePrice.model.DailyStockDetails;
import com.cognizant.mfpe.dailySharePrice.repository.StockRepository;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class ServiceTest {

	@InjectMocks
	StockDetailsServiceImpl service;
	
	@Mock
	StockRepository repo;
	
	@Mock
	DailyStockDetails stockDetails;
	
	@Test
	public void findByStockNameTest() {
		when(repo.findByStockName(anyString())).thenReturn(stockDetails);
		service.findByStockName(anyString());
		verify(repo).findByStockName(anyString());
	}

}

