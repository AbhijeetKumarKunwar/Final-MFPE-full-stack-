
INSERT INTO mutualfund_details (mutualfund_id,mutualfund_name,mutualfund_value) VALUES (1,'Kotak',7000.00);
INSERT INTO mutualfund_details (mutualfund_id,mutualfund_name,mutualfund_value) VALUES (2,'Axis',1700);
INSERT INTO mutualfund_details (mutualfund_id,mutualfund_name,mutualfund_value) VALUES (3,'Mahindra',1200);
INSERT INTO mutualfund_details (mutualfund_id,mutualfund_name,mutualfund_value) VALUES (4,'Invesco',5000);
  