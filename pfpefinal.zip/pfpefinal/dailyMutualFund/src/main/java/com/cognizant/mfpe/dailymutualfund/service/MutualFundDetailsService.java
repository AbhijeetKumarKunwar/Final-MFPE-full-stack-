package com.cognizant.mfpe.dailymutualfund.service;

import com.cognizant.mfpe.dailymutualfund.model.DailyMutualFundDetails;

public interface MutualFundDetailsService {
	public DailyMutualFundDetails findByMutualFundName(String mutualFundName);
	

}

//create table mutualfund_details(mutualfund_id int,mutualfund_name varchar2(20),mutualfund_value decimal(6,2));
