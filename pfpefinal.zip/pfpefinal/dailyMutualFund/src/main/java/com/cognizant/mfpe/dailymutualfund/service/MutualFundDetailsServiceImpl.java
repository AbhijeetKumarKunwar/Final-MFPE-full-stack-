package com.cognizant.mfpe.dailymutualfund.service;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.mfpe.dailymutualfund.model.DailyMutualFundDetails;
import com.cognizant.mfpe.dailymutualfund.repository.MutualFundRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MutualFundDetailsServiceImpl implements MutualFundDetailsService {
	
	@Autowired
	MutualFundRepository mutualFundRepository;

	@Override
	@Transactional
	public DailyMutualFundDetails findByMutualFundName(String mutualFundName) {
		log.info("findByMutualFundName() method called");
		
	// System.out.println( mutualFundRepository.findByMutualFundName(mutualFundName));
	 return mutualFundRepository.findByMutualFundName(mutualFundName);
		
	}
}
