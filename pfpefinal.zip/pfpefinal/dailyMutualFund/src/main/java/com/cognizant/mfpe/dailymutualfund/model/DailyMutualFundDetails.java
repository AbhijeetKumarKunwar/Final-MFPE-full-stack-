package com.cognizant.mfpe.dailymutualfund.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
//@ToString
@Table(name="MUTUALFUND_DETAILS")
public class DailyMutualFundDetails {
	
	@Id
	@Column(name = "MUTUALFUND_ID")
	private int mutualFundId;
	
	@Column(name = "MUTUALFUND_NAME", length = 20)
	private String mutualFundName;
	
	@Column(name = "MUTUALFUND_VALUE")
	private double mutualFundValue;
	
	
}
