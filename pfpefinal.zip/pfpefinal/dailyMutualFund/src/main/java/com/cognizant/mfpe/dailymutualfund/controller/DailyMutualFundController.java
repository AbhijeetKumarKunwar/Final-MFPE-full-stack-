package com.cognizant.mfpe.dailymutualfund.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.mfpe.dailymutualfund.client.AuthClient;
import com.cognizant.mfpe.dailymutualfund.exception.MutualFundNotFoundException;
import com.cognizant.mfpe.dailymutualfund.model.AuthResponse;
import com.cognizant.mfpe.dailymutualfund.model.DailyMutualFundDetails;
import com.cognizant.mfpe.dailymutualfund.service.MutualFundDetailsService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
//@RequestMapping(path = "/stock")
public class DailyMutualFundController {

	@Autowired
	private MutualFundDetailsService mutualFundDetailsService;

	@Autowired
	private AuthClient authclient;

	@GetMapping(path = "/mutualFundNav/{name}")
	public ResponseEntity<?> mutualFundNav(@RequestHeader(name = "Authorization") String token, @PathVariable("name") String mutualFundName) {
		log.info("AuthClient: VerifyToken method called");
		AuthResponse authResponse = authclient.getValidity(token);
		if (authResponse.isValid()) {
			log.info("AuthClient:Authentication validated");
			DailyMutualFundDetails mutualFund = mutualFundDetailsService.findByMutualFundName(mutualFundName);
			if(mutualFund != null)
				return new ResponseEntity<>(mutualFund, HttpStatus.OK);
			else{
				throw new MutualFundNotFoundException("this mutualFund does'nt  exist");
			}
		} 
		else {
			log.error("AuthClient: Authentication failed");
			return new ResponseEntity<>("You are not LoggedIn", HttpStatus.FORBIDDEN);
		}
	}
}
