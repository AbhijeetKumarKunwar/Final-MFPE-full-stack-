package com.cognizant.mfpe.dailymutualfund.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.jdbc.Expectation;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cognizant.mfpe.dailymutualfund.client.AuthClient;
import com.cognizant.mfpe.dailymutualfund.exception.MutualFundNotFoundException;
import com.cognizant.mfpe.dailymutualfund.model.AuthResponse;
import com.cognizant.mfpe.dailymutualfund.model.DailyMutualFundDetails;
import com.cognizant.mfpe.dailymutualfund.repository.MutualFundRepository;
import com.cognizant.mfpe.dailymutualfund.service.MutualFundDetailsService;




@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class ControllerTest {
	
	@Mock
	MutualFundDetailsService service;

	@InjectMocks
	DailyMutualFundController controller;

	@Mock
	AuthClient authClient;

	@Mock
	MutualFundRepository mutualFundRepository;

	@Mock
	DailyMutualFundDetails mutualFund;
	
	AuthResponse authResponse;
	List<DailyMutualFundDetails> mutualFundDetailsList;
	String token="admin";
	String mutualFundName="Kotak";
	boolean isValid = true;

	
	
	@Before
	public void setUp() {
		authResponse = new AuthResponse("userid", "username", true);
		mutualFundDetailsList= new ArrayList<DailyMutualFundDetails>();
		mutualFundDetailsList.add(new DailyMutualFundDetails(1, "Kotak", 123.12));
		mutualFundDetailsList.add(new DailyMutualFundDetails(2, "HDFC", 399.12));
	}

	@Test
	public void getallTest() {
		when(authClient.getValidity("token")).thenReturn(authResponse);
		//when(authResponse.isValid()).thenReturn(true);
		
		assertNotNull(authResponse.isValid());
		when(service.findByMutualFundName("Kotak")).thenReturn(new DailyMutualFundDetails(1, "Kotak", 123.12));
		assertNotNull(mutualFund);
		ResponseEntity<?> mutualFund = controller.mutualFundNav("token","Kotak");
		assertEquals(200, mutualFund.getStatusCodeValue());
		assertNotNull(mutualFund);
	}
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	@Test
	public void getallNotFoundTest() {
		when(authClient.getValidity("token")).thenReturn(authResponse);
		assertNotNull(authResponse.isValid());
		when(service.findByMutualFundName("Kotak")).thenReturn(null);
		thrown.expect(MutualFundNotFoundException.class);
		ResponseEntity<?> mutualFund = controller.mutualFundNav("token", "");
		assertEquals(403, mutualFund.getStatusCodeValue());

		}

	

	@Test
	public void getallFail() {
		when(authClient.getValidity("token")).thenReturn(new AuthResponse("", "", false));
		when(service.findByMutualFundName("Kotak")).thenReturn(new DailyMutualFundDetails(1, "Kotak", 123.12));
		ResponseEntity<?> mutualFund = controller.mutualFundNav("token", "Kotak");
		assertEquals(403, mutualFund.getStatusCodeValue());
	}


}