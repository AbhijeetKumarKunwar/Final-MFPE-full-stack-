package com.cognizant.mfpe.dailymutualfund.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;




@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class ModelTest {

	@Test
	public void gettersetterAuthResponseTest() {
		AuthResponse response = new AuthResponse();
		response.setName("test");
		response.setUid("testuid");
		response.setValid(true);

		assertEquals("test", response.getName());
		assertEquals("testuid", response.getUid());
		assertEquals(true, response.isValid());
	}

	@Test
	public void constructerAuthResponseTest() {
		AuthResponse responseNoArg = new AuthResponse();
		assertNotNull(responseNoArg);
		AuthResponse responseAllArg = new AuthResponse("testuid", "test", true);
		assertNotNull(responseAllArg);
	}
	
	@Test
	public void gettersetterMutualFundDetailsTest() {
		DailyMutualFundDetails mutualFundDetails = new DailyMutualFundDetails();
		mutualFundDetails.setMutualFundId(1);
		mutualFundDetails.setMutualFundName("Kotak");
		mutualFundDetails.setMutualFundValue(7000.00);
		assertEquals(1, mutualFundDetails.getMutualFundId());
		assertEquals("Kotak", mutualFundDetails.getMutualFundName());
		assertEquals(7000.00, mutualFundDetails.getMutualFundValue(),0);
}
	
	@Test
	public void constructerMutualFundDetailsTest() {
		DailyMutualFundDetails mutualFundNoArgs = new DailyMutualFundDetails();
		assertNotNull(mutualFundNoArgs);
		DailyMutualFundDetails mutualFundDetailsAllArg = new DailyMutualFundDetails(1, "Kotak", 7000.00);
		assertNotNull(mutualFundDetailsAllArg);
	}
//
//	@Test
//	public void toStringMutualFundDetailsTest() {
//		MutualFundDetails mutualFundDetails = new MutualFundDetails();
//		mutualFundDetails.setMutualFundId(1);
//		mutualFundDetails.setMutualFundName("Kotak");
//		mutualFundDetails.setMutualFundValue(7000.00);
//
//		assertTrue(mutualFundDetails.toString().startsWith(MutualFundDetails.class.getSimpleName()));
//		//assertTrue(mutualFundDetails.toString().endsWith(suffix);
//		assertTrue(mutualFundDetails.toString().endsWith("(mutualFundId=1, mutualFundName=Kotak, mutualFundvalue=7000.00)"));
//	}

	
	
	
}
