package com.congnizant.mfp.calculateNetWorth.model;

import org.junit.Assert;
import org.junit.Before;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.congnizant.mfp.calculateNetWorth.exception.ExceptionResponse;



@RunWith(SpringJUnit4ClassRunner.class)
class NetWorthModelTest {
	private static final double DELTA = 0;
	double netWorth=2500.2;
	AuthResponse authResponse;
	AssetSaleResponse response;
	List<PortFolioDetails> portfolioList;

	@Test
	public void testGetterAndSetterAssetSaleResponse() {
		AssetSaleResponse response = new AssetSaleResponse();
		response.setSaleStatus(true);;
		response.setNetWorth(2500.00);

		assertEquals(true, response.isSaleStatus());
		assertEquals(2500.00,response.getNetWorth(),DELTA);

	}

	@Test
	public void constructerAssetSaleRespone() {
		AssetSaleResponse noArg = new AssetSaleResponse();
		assertNotNull(noArg);
		AssetSaleResponse responseAllArg = new AssetSaleResponse(true, 2500);
		assertNotNull(responseAllArg);
	}

	@Test
	public void testGetterAndSetterAuthResponse() {
		AuthResponse response = new AuthResponse();
		response.setName("test");
		response.setUId("testuid");
		response.setValid(true);

		assertEquals("test", response.getName());
		assertEquals("testuid", response.getUId());
		assertEquals(true, response.isValid());

	}

	@Test
	public void constructerAuthResponseTest() {
		AuthResponse noArg = new AuthResponse();
		assertNotNull(noArg);
		AuthResponse responseAllArg = new AuthResponse("testuid", "test", true);
		assertNotNull(responseAllArg);
	}

	@Test
	public void testGettterAndSetterDailyMutual() {
		DailyMutualFundDetails dailyMutual = new DailyMutualFundDetails();
		dailyMutual.setMutualFundId(1);
		dailyMutual.setMutualFundName("Icici");
		dailyMutual.setMutualFundValue(100.00);
		assertEquals(1, dailyMutual.getMutualFundId());
		
		assertEquals("Icici", dailyMutual.getMutualFundName());
		assertEquals(100.00, dailyMutual.getMutualFundValue(),DELTA);

	}

	@Test
	public void testConstructorDailyMutual() {
		DailyMutualFundDetails noArg = new DailyMutualFundDetails();
		assertNotNull(noArg);
		DailyMutualFundDetails arg = new DailyMutualFundDetails(1, "icici", 100);
		assertNotNull(arg);
	}

	@Test
	public void testGetterAndSetterDailyStock() {
		DailyStockDetails daily = new DailyStockDetails();
		daily.setStockId(111);
		daily.setStockName("sbi");
		daily.setStockValue(15);
		assertEquals(111, daily.getStockId());
		assertEquals("sbi", daily.getStockName());
		assertEquals(15, daily.getStockValue(),DELTA);

	}

	@Test
	public void testConstructorDailyStock() {
		DailyStockDetails noArg = new DailyStockDetails();
		assertNotNull(noArg);
		DailyStockDetails arg = new DailyStockDetails(1, "icici", 100);
		assertNotNull(arg);
	}

	@Test
	public void testGetterAndSetterMutualFundDetails() {
		MutualFundDetails mutual = new MutualFundDetails();
		mutual.setMutualFundName("kotak");
		mutual.setMutualFundUnits(100);
		mutual.setMutualId(100);
		mutual.setPortFolio(null);
		assertEquals(100, mutual.getMutualFundUnits());
		assertEquals("kotak", mutual.getMutualFundName());
		assertEquals(100, mutual.getMutualId());
		assertEquals(null,mutual.getPortFolio());

	}

	@Test
	public void testConstructorMutualFundDetails() {
		MutualFundDetails noArg = new MutualFundDetails();
		assertNotNull(noArg);
		MutualFundDetails arg = new MutualFundDetails(100, "icici", 100, null);
		assertNotNull(arg);
	}



	@Test
	public void testGetterAndSetterProtFolioDetails() {
		List<MutualFundDetails>mfd=new ArrayList<MutualFundDetails>();
		
		MutualFundDetails arg = new MutualFundDetails(100, "icici", 100, null);
		StockDetails st=new StockDetails(100,"yes",200,null);
		List<StockDetails> sd=new ArrayList<StockDetails>();
		mfd.add(arg);
		sd.add(st);
		PortFolioDetails prot = new PortFolioDetails();
		prot.setName("abhi");
		prot.setPortFolioId("abc");
		prot.setMutualFundList(mfd);
		prot.setStockList(sd);
		assertEquals("abhi",prot.getName());
		assertEquals("abc",prot.getPortFolioId());
		assertNotNull(prot.getMutualFundList());
		assertNotNull(prot.getStockList());

	}
	
//	@Test
//	public void testConstructorProtFolioDetails() {
//		List<MutualFundDetails>mfd=new ArrayList<MutualFundDetails>();
//		MutualFundDetails arg = new MutualFundDetails(100, "icici", 100, null);
//		
//		StockDetails st=new StockDetails(100,"yes",200,null);
//		List<StockDetails> sd=new ArrayList<StockDetails>();
//		mfd.add(arg);
//		sd.add(st);
//		PortFolioDetails noArg = new PortFolioDetails();
//		assertNotNull(noArg);
//		PortFolioDetails Allarg = new PortFolioDetails("ashish","ashish",List<MutualFundDetails>,sd);
//		assertNotNull(Allarg);
//	}
	
	@Test
	public void testGetterAndSetterStockDetails() {
		StockDetails mutual = new StockDetails();
		mutual.setStockName("kotak");
		mutual.setStockCount(100);
		mutual.setStockId(100);
		mutual.setPortFolio(null);
		assertEquals(100, mutual.getStockCount());
		assertEquals("kotak", mutual.getStockName());
		assertEquals(100, mutual.getStockId());
		assertEquals(null,mutual.getPortFolio());

	}

	@Test
	public void testConstructorStockDetails() {
		MutualFundDetails noArg = new MutualFundDetails();
		assertNotNull(noArg);
		MutualFundDetails arg = new MutualFundDetails(100, "icici", 100, null);
		assertNotNull(arg);
	}
	
	Date datestamp;

	@Test
	public void gettersetterExceptionResponseTest() {
		ExceptionResponse response = new ExceptionResponse();
		response.setDatestamp(datestamp);
		response.setDetails("details");;
		response.setMessage("message");
	
		assertEquals(datestamp,response.getDatestamp());
		assertEquals("details", response.getDetails());
		assertEquals("message", response.getMessage());
	}
	@Test
	public void constructerExceptionResponseTest() {
		ExceptionResponse responseNoArg = new ExceptionResponse();
		assertNotNull(responseNoArg);
		ExceptionResponse responseAllArg = new ExceptionResponse(datestamp, "details", "message");
		assertNotNull(responseAllArg);
	}
UserLoginCredential user=new UserLoginCredential();
	
	@Test
	public void testuserAllConstructor()
	{
		UserLoginCredential hospital=new UserLoginCredential("ab", "ab", "ab", null);
		assertEquals(hospital.getUserid(), "ab");
	}
	
	@Test
	public void testUserid()
	{
		user.setUserid("abc");
		assertEquals(user.getUserid(), "abc");
	}
	
	@Test
	public void testUserPassword()
	{
		user.setUpassword("abc");
		assertEquals(user.getUpassword(), "abc");
	}
	
	@Test
	public void testUserName()
	{
		user.setUname("abc");
		assertEquals(user.getUname(), "abc");
	}
	
	@Test
	public void testAuthToken()
	{
		user.setAuthToken("abc");
		assertEquals(user.getAuthToken(),"abc");
	}
	
	@Test
	public void testoString() {
		String string = user.toString();
		assertEquals(user.toString(),string);
	}
	
	@Test
	public void testGetterAndSetterCalculateResponse() {
		CalculateReaponse response = new CalculateReaponse();
		response.setCalculateStatus(true);
		response.setTotelNetWorth(2500.00);

		assertEquals(true, response.isCalculateStatus());
		assertEquals(2500.00,response.getTotelNetWorth(),DELTA);

	}

	@Test
	public void constructerCalculateRespone() {
		CalculateReaponse noArg = new CalculateReaponse();
		assertNotNull(noArg);
		CalculateReaponse responseAllArg = new CalculateReaponse(true, 2500.00);
		assertNotNull(responseAllArg);
	}

	
}