package com.congnizant.mfp.calculateNetWorth.service;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.BooleanSupplier;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.congnizant.mfp.calculateNetWorth.Dao.PortFolioRepo;
import com.congnizant.mfp.calculateNetWorth.client.AuthClient;
import com.congnizant.mfp.calculateNetWorth.client.DailyShareClient;
import com.congnizant.mfp.calculateNetWorth.model.AssetSaleResponse;
import com.congnizant.mfp.calculateNetWorth.model.AuthResponse;
import com.congnizant.mfp.calculateNetWorth.model.CalculateReaponse;
import com.congnizant.mfp.calculateNetWorth.model.DailyStockDetails;
import com.congnizant.mfp.calculateNetWorth.model.MutualFundDetails;
import com.congnizant.mfp.calculateNetWorth.model.PortFolioDetails;
import com.congnizant.mfp.calculateNetWorth.model.StockDetails;
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class NetServiceTest {

	@InjectMocks
	PortFolioServiceImpl service;
	
	@Mock
	PortFolioService portService;
	
	@Mock
	PortFolioRepo repo;
	@Mock
	CalculateReaponse cresponse;
	
	@Mock
	PortFolioDetails portFolioDetails;
	@Mock
	AuthClient authClient;
	@Mock
	StockDetails stock;
	@Mock
	DailyShareClient dailyShareClient;
	@Mock
	DailyStockDetails dailyStockDetails;

	AuthResponse authResponse;
	AssetSaleResponse response;
	List<PortFolioDetails> portfolioList;
	String token ="ashish";
	private static final double DELTA = 0;	
	
	
	
	@Test
	public void findByIdTest() {
		when(repo.findById(anyString())).thenReturn(Optional.of(portFolioDetails));
		service.findById(anyString());
		verify(repo).findById(anyString());
}

	
	@Test
	public void findSaveTest() {
	//authResponse = new AuthResponse("userid", "username", true);
	portfolioList= new ArrayList< PortFolioDetails>();
	
	ArrayList<MutualFundDetails> list = new ArrayList<MutualFundDetails>();
	list.add(new MutualFundDetails(1,"Kotak",1,new PortFolioDetails()));
	
	
	ArrayList<StockDetails> list1 = new ArrayList<StockDetails>();
	list1.add(new StockDetails(1,"Apple",1,new PortFolioDetails()));
	
	
	portfolioList.add(new PortFolioDetails("ashish","ashish",list1,list));
	
		
		PortFolioDetails p =new PortFolioDetails("ashish","ashish",list1,list);
		
		when(repo.save(p)).thenReturn(p);
		///verify(repo.save(p));
		//assertThat(service.savePortFolio(p)).isEqualTo("ashish","ashish",list1,list);
		//assertEquals(p,service.savePortFolio(p));

}

	@Test
	public void findCalculateTest() {
		String portFolioId = "ashish";
		when(portService.findById(anyString())).thenReturn(portFolioDetails);
		service.calculateNetworth(token, portFolioId);
		assertNotNull(portFolioDetails);
		String stockName="apple";
		when(dailyShareClient.dailySharePrice(portFolioId, stockName)).thenReturn(dailyStockDetails);
		double d= cresponse.getTotelNetWorth();
		assertEquals(0.0,d,DELTA);
		boolean status=true;
		//assertTrue(status);
		assertEquals(false,cresponse.isCalculateStatus());
}

	@Test
	public void findCalculateFailTest() {
		
		service.calculateNetworth(token, null);
		
		assertNull(null);
		double d= cresponse.getTotelNetWorth();
		assertEquals(0.0,d,DELTA);
		boolean status=true;
		//assertTrue(status);
		assertEquals(false,cresponse.isCalculateStatus());
}

	@Test
	public void findgetAllFailTest() {
		

		when(authClient.getValidity(token)).thenReturn(authResponse);
		when(portService.findById(anyString())).thenReturn(portFolioDetails);
		service.getAll(token, anyString());
		//(stock.setPortFolio(portFolioDetails),null);
		assertNotNull(portFolioDetails);

}
	@Test
	public void findSellTest() {
		
		when(authClient.getValidity(token)).thenReturn(authResponse);
		when(portService.findById(anyString())).thenReturn(portFolioDetails);
		assertNotNull(portFolioDetails);
		service.sell(token, portFolioDetails);

		
		double d =response.getNetWorth();
		assertEquals(0.0,d,DELTA);
		boolean st = response.isSaleStatus();
		assertEquals(true,st);
		//service.sell(token, portFolioDetails);
		//(stock.setPortFolio(portFolioDetails),null);
		assertNotNull(response);

}	


}