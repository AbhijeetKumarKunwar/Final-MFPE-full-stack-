package com.congnizant.mfp.calculateNetWorth.controller;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.congnizant.mfp.calculateNetWorth.Dao.PortFolioRepo;
import com.congnizant.mfp.calculateNetWorth.client.AuthClient;
import com.congnizant.mfp.calculateNetWorth.model.AssetSaleResponse;
import com.congnizant.mfp.calculateNetWorth.model.AuthResponse;
import com.congnizant.mfp.calculateNetWorth.model.CalculateReaponse;
import com.congnizant.mfp.calculateNetWorth.model.MutualFundDetails;
import com.congnizant.mfp.calculateNetWorth.model.PortFolioDetails;
import com.congnizant.mfp.calculateNetWorth.model.StockDetails;
import com.congnizant.mfp.calculateNetWorth.service.PortFolioService;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.awt.MenuItem;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class ControllerTest {

	@Mock
	PortFolioService service;

	@InjectMocks
	NetWorthController controller;

	@Mock
	AuthClient authClient;

	@Mock
	PortFolioRepo repo;

	@Mock
	PortFolioDetails portfolioDetails;
	@Mock
	CalculateReaponse calculateReaposne;

	AuthResponse authResponse;
	AssetSaleResponse response;
	List<PortFolioDetails> portfolioList;
	
	
	
	String token="admin";
	String protofolioId ="ashish";
	boolean isValid = true;
	String name="ashish";
	boolean status =true;
	double netWorth=2500.00;

	

	@Before
	public void setUp() {
		authResponse = new AuthResponse("userid", "username", true);
		portfolioList= new ArrayList< PortFolioDetails>();
		
		ArrayList<MutualFundDetails> list = new ArrayList<MutualFundDetails>();
		list.add(new MutualFundDetails(1,"Kotak",1,new PortFolioDetails()));
		list.add(new MutualFundDetails(2,"Axis",2,new PortFolioDetails()));
		
		ArrayList<StockDetails> list1 = new ArrayList<StockDetails>();
		list1.add(new StockDetails(1,"Apple",1,new PortFolioDetails()));
		list1.add(new StockDetails(2,"Amazon",2,new PortFolioDetails()));
		
		portfolioList.add(new PortFolioDetails("ashish","ashish",list1,list));
		portfolioList.add(new PortFolioDetails("ashish","ashish",list1,list));
	}
	
	@Test
	public void getallCalculateNetWorthTest() {
	
		when(service.calculateNetworth(token, "ashish")).thenReturn(new CalculateReaponse(true,2500.00));
		assertNotNull(status);
		assertNotNull(netWorth);

	}
//	@Rule
//	public ExpectedException thrown = ExpectedException.none();
//	
//	@Test
//	public void getallFailCalculateNetWorthTest() {
//	
//		when(service.calculateNetworth(token, "ashish")).thenReturn(null);
//		
//		thrown.expect(ExcetptionRaise.class);
		
		//assertNotNull(status);
		//equals((double) controller.calculateNetworth("token", "protofolioId"));

	//}
	

	

	@Test
	public void getallSellTest() {
	
		when(service.sell("token", portfolioDetails)).thenReturn(response);
		
		equals((AssetSaleResponse) controller.sell(token, portfolioDetails));

	}
	@Test
	public void getallDetailsTest() {
	
		when(service.getAll(token, name)).thenReturn(portfolioDetails);
		
		equals((PortFolioDetails) controller.getPortFolio(token, name));

	}
	
	

}