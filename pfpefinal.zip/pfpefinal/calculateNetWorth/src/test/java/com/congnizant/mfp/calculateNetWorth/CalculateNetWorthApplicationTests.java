package com.congnizant.mfp.calculateNetWorth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculateNetWorthApplicationTests {

	@Test
	void contextLoads() {
	}

}
