package com.congnizant.mfp.calculateNetWorth.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.congnizant.mfp.calculateNetWorth.model.MutualFundDetails;

@Repository
public interface MutualFundRepo extends JpaRepository<MutualFundDetails, Integer> {

	MutualFundDetails findByMutualFundName(String mutualFundName);

}
