package com.congnizant.mfp.calculateNetWorth.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AuthResponse {
	// this is authentication response class
	private String uId;
	private String name;
	private boolean isValid;

}
