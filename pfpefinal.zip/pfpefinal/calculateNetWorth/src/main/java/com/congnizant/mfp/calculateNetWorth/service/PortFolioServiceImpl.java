package com.congnizant.mfp.calculateNetWorth.service;

import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.congnizant.mfp.calculateNetWorth.Dao.MutualFundRepo;
import com.congnizant.mfp.calculateNetWorth.Dao.PortFolioRepo;
import com.congnizant.mfp.calculateNetWorth.Dao.StockRepo;
import com.congnizant.mfp.calculateNetWorth.client.AuthClient;
import com.congnizant.mfp.calculateNetWorth.client.DailyMutualClient;
import com.congnizant.mfp.calculateNetWorth.client.DailyShareClient;
import com.congnizant.mfp.calculateNetWorth.exception.ExcetptionRaise;
import com.congnizant.mfp.calculateNetWorth.model.AssetSaleResponse;
import com.congnizant.mfp.calculateNetWorth.model.AuthResponse;
import com.congnizant.mfp.calculateNetWorth.model.CalculateReaponse;
import com.congnizant.mfp.calculateNetWorth.model.DailyMutualFundDetails;
import com.congnizant.mfp.calculateNetWorth.model.DailyStockDetails;
import com.congnizant.mfp.calculateNetWorth.model.MutualFundDetails;
import com.congnizant.mfp.calculateNetWorth.model.PortFolioDetails;
import com.congnizant.mfp.calculateNetWorth.model.StockDetails;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PortFolioServiceImpl implements PortFolioService {

	@Autowired
	private PortFolioRepo portFolioRepo;

	@Autowired
	private PortFolioService portFolioService;

	@Autowired
	private DailyMutualClient dailyMutualClient;

	@Autowired
	private AuthClient authClient;

	@Autowired
	private DailyShareClient dailyShareClient;

	@Autowired
	private StockRepo stcokRepo;
	
	@Autowired
	private MutualFundRepo mutualRepo;
	
	@Override
	public PortFolioDetails findById(String id) {
		// TODO Auto-generated method stub
		log.debug("Inside findById protofolio serviceImpl class");
		return portFolioRepo.findById(id).orElse(null);

	}

	@Override
	@Transactional
	public void savePortFolio(PortFolioDetails p) {
  
		log.debug("Inside save protofolio serviceImpl class");
		
		portFolioRepo.save(p);
	}

	@Override
	public CalculateReaponse calculateNetworth(String token, String portFolioId) {
		double totalNetWorth = 0;
		CalculateReaponse status=new CalculateReaponse();
		PortFolioDetails portFolio;
		log.debug("Inside calculate Networth protofolio serviceImpl class");		
			portFolio= portFolioService.findById(portFolioId);
			
		if(portFolio==null)
		{
			log.debug("Inside calculate Networth protofolio serviceImpl ,here id is not available");
			status.setCalculateStatus(false);
			status.setTotelNetWorth(0);
			return status;
		}
		List<StockDetails> stockDetailsList = portFolio.getStockList();
		List<MutualFundDetails> mutualFundDetailsList = portFolio.getMutualFundList();
		for (StockDetails stocks : stockDetailsList) {
			DailyStockDetails dailyStock = dailyShareClient.dailySharePrice(token, stocks.getStockName());
			totalNetWorth += (dailyStock.getStockValue() * stocks.getStockCount());
		} 
		for (MutualFundDetails mutual : mutualFundDetailsList) {
			DailyMutualFundDetails dailyMutual = dailyMutualClient.mutualFundNav(token, mutual.getMutualFundName());
			totalNetWorth += (dailyMutual.getMutualFundValue() * mutual.getMutualFundUnits());
		}
		status.setCalculateStatus(true);
		status.setTotelNetWorth(totalNetWorth);
		return status;
	}

	@Override
	public AssetSaleResponse sell(String token, PortFolioDetails portFolio) {

		log.debug("Inside sell method of protofolio serviceImpl class");
		AssetSaleResponse assetSaleResponse = new AssetSaleResponse();
		AuthResponse authResponse = authClient.getValidity(token);

		List<StockDetails> sellStockDetailsList = portFolio.getStockList();// this is a request coming from user
																			// end for sell (portFolio)...
		List<MutualFundDetails> sellMutualFundDetailsList = portFolio.getMutualFundList();
		String sellPortFolioId = portFolio.getPortFolioId();
		// String portName = portFolio.getName();

		PortFolioDetails storedUser = portFolioService.findById(sellPortFolioId);// will give data from database
																					// which is already stored
		// with a given ID
		List<StockDetails> storedUserStockList = storedUser.getStockList();
		List<MutualFundDetails> storedUserMutualFundList = storedUser.getMutualFundList();

		double totalStockPrice = 0;

		for (StockDetails sellStockDetail : sellStockDetailsList) {

			DailyStockDetails dailyStock = dailyShareClient.dailySharePrice(token, sellStockDetail.getStockName());

			totalStockPrice = totalStockPrice + (sellStockDetail.getStockCount() * dailyStock.getStockValue());

			// System.out.println(stockDetail.getStockCount() + " " +
			// stockDetail.getStockName());
			// for (StockDetails storedUserStockDetail : storedUserStockList)
			Iterator it = storedUserStockList.iterator();
			while (it.hasNext()) {
				StockDetails storedUserStockDetail = (StockDetails) it.next();

				if (storedUserStockDetail.getStockName().equals(sellStockDetail.getStockName())) {

					if (storedUserStockDetail.getStockCount() - sellStockDetail.getStockCount() == 0) {
						it.remove();
					} else {
						storedUserStockDetail
								.setStockCount(storedUserStockDetail.getStockCount() - sellStockDetail.getStockCount());
					}
				}
			}
		}

		double totalMutualPrice = 0;
		for (MutualFundDetails sellMutualFundDetail : sellMutualFundDetailsList) {

			DailyMutualFundDetails dailyMutualFund = dailyMutualClient.mutualFundNav(token,
					sellMutualFundDetail.getMutualFundName());
			totalMutualPrice = totalMutualPrice
					+ (sellMutualFundDetail.getMutualFundUnits() * dailyMutualFund.getMutualFundValue());

			// System.out.println(mutualFundDetail.getMutualFundName() + " " +
			// mutualFundDetail.getMutualFundUnits());

			Iterator it = storedUserMutualFundList.iterator();
			while (it.hasNext()) {
				MutualFundDetails storedUserMutualFundDetail = (MutualFundDetails) it.next();
				if (storedUserMutualFundDetail.getMutualFundName().equals(sellMutualFundDetail.getMutualFundName())) {
					if (storedUserMutualFundDetail.getMutualFundUnits()
							- sellMutualFundDetail.getMutualFundUnits() == 0) {
						it.remove();
					} else {
						storedUserMutualFundDetail.setMutualFundUnits(storedUserMutualFundDetail.getMutualFundUnits()
								- sellMutualFundDetail.getMutualFundUnits());
					}
				}
			}

		}

		double totalNetWorth = totalStockPrice + totalMutualPrice;

		assetSaleResponse.setNetWorth(totalNetWorth);
		assetSaleResponse.setSaleStatus(true);

		portFolioService.savePortFolio(storedUser);
		return assetSaleResponse;
	}
	
	@Override
	public PortFolioDetails getAll(String token,String name) {
		
		log.debug("Inside getAll protofolio serviceImpl ,this will return the entire protofolio of customer");
		AuthResponse authResponse = authClient.getValidity(token);
		
		PortFolioDetails portFolio = portFolioService.findById(name);

		List<StockDetails> stockList = portFolio.getStockList();
		List<MutualFundDetails> mutualFundList = portFolio.getMutualFundList();

		for (StockDetails stock : stockList) {
			stock.setPortFolio(null);
		}

		for (MutualFundDetails stock : mutualFundList) {
			stock.setPortFolio(null);
		}
		return portFolio;
	}

}
