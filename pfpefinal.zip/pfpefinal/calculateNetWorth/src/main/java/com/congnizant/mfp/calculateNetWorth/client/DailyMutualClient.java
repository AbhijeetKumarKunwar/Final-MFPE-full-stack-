package com.congnizant.mfp.calculateNetWorth.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.congnizant.mfp.calculateNetWorth.model.DailyMutualFundDetails;

@FeignClient(url = "${dailyMutual.path}", name = "Daily-MutualFund")
public interface DailyMutualClient {
	@GetMapping(path = "/mutualFundNav/{name}")
	public DailyMutualFundDetails mutualFundNav(@RequestHeader(name = "Authorization") String token,
			@PathVariable("name") String mutualFundName);

}
