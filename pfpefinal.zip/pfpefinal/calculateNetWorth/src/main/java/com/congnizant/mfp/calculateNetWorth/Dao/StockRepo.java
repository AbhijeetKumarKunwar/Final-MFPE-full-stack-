package com.congnizant.mfp.calculateNetWorth.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.congnizant.mfp.calculateNetWorth.model.PortFolioDetails;
import com.congnizant.mfp.calculateNetWorth.model.StockDetails;
@Repository
public interface StockRepo extends JpaRepository<StockDetails, Integer> {

	StockDetails findByStockNameAndPortFolio(String stockName,PortFolioDetails p);

}
