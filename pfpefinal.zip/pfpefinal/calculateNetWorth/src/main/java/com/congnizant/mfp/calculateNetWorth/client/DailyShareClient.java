package com.congnizant.mfp.calculateNetWorth.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.congnizant.mfp.calculateNetWorth.model.DailyStockDetails;

@FeignClient(url="${dailyShare.path}",name="Daily-Share")

public interface DailyShareClient {
	@GetMapping(path = "/dailySharePrice/{name}")
	public DailyStockDetails dailySharePrice(@RequestHeader(name = "Authorization") String token, @PathVariable("name") String stockName);
}
