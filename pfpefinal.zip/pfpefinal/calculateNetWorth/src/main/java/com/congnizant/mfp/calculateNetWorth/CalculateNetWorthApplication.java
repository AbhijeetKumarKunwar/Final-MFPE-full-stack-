package com.congnizant.mfp.calculateNetWorth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class CalculateNetWorthApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculateNetWorthApplication.class, args);
	}

}
