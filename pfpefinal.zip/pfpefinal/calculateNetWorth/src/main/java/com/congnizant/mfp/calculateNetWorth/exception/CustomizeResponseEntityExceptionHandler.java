package com.congnizant.mfp.calculateNetWorth.exception;


import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

 
import lombok.extern.slf4j.Slf4j;

@RestController
//This will provide response back to the all  controller
@ControllerAdvice
//This is apllicable to all others controller, we use when we have to share the 
//component to all controller class ,it also handle date
@Slf4j
public class CustomizeResponseEntityExceptionHandler 
extends ResponseEntityExceptionHandler 
{
/*This abtract class ,it can be extended to provide centralise exception handling across
 all exception handler metod, This can use as base class for diffrent custamize excrption */
	@ExceptionHandler(ExcetptionRaise.class)//By this way we can customize for each exception
	public final ResponseEntity<Object> userNotFoundExceptions
	(Exception ex,WebRequest request)
	{
		log.debug("Inside the Customise Excetption handler method");
	ExceptionResponse exp=	new ExceptionResponse(new Date(),ex.getMessage(),request.getDescription(false));
		return new ResponseEntity(exp,HttpStatus.NOT_FOUND);
	}

	
}