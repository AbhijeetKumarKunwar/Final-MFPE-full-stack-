package com.congnizant.mfp.calculateNetWorth.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.congnizant.mfp.calculateNetWorth.model.PortFolioDetails;
@Repository
public interface PortFolioRepo extends JpaRepository<PortFolioDetails, String> {
	  

}
