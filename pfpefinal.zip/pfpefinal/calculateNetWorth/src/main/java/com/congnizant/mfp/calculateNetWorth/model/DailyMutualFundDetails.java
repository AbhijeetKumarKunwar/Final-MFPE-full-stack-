package com.congnizant.mfp.calculateNetWorth.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
//@ToString
public class DailyMutualFundDetails {
	
	
	private int mutualFundId;
	
	private String mutualFundName;
	
	private double mutualFundValue;
	
	
}
