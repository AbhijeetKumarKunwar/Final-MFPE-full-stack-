package com.congnizant.mfp.calculateNetWorth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.congnizant.mfp.calculateNetWorth.client.AuthClient;
import com.congnizant.mfp.calculateNetWorth.exception.ExcetptionRaise;
import com.congnizant.mfp.calculateNetWorth.model.AssetSaleResponse;
import com.congnizant.mfp.calculateNetWorth.model.AuthResponse;
import com.congnizant.mfp.calculateNetWorth.model.CalculateReaponse;
import com.congnizant.mfp.calculateNetWorth.model.PortFolioDetails;
import com.congnizant.mfp.calculateNetWorth.service.PortFolioService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
public class NetWorthController {

	@Autowired
	private PortFolioService portFolioService; // to call the methods from service layer.. in controller

	@Autowired
	private AuthClient authClient;
	
	@RequestMapping(path = "/calculateNetworth/{protofolioId}")
	public double calculateNetworth(@RequestHeader(name = "Authorization") String token,
			@PathVariable("protofolioId") String protofolioId) {
		AuthResponse authResponse=authClient.getValidity(token);
		if(authResponse.isValid())
		{
		log.debug("Calculate-Networth  controller method is running");
		CalculateReaponse status = portFolioService.calculateNetworth(token, protofolioId);
		if(!status.isCalculateStatus())
			throw new ExcetptionRaise("The given Protofolio id is not Valid");

		return status.getTotelNetWorth();
		}
		else {
		
			throw new ExcetptionRaise("The given Protofolio id is not Valid");
		}
	}

	@RequestMapping(path = "/sellStock", method = RequestMethod.POST)
	public AssetSaleResponse sell(@RequestHeader(name = "Authorization") String token,
			@RequestBody PortFolioDetails portFolio) {
    log.debug("Inside Controller sell method...");
		AssetSaleResponse respone = portFolioService.sell(token, portFolio);
		return respone;
	}

	@RequestMapping(path = "/getPortFolio/{name}", method = RequestMethod.GET)
	public PortFolioDetails getPortFolio(@RequestHeader(name = "Authorization") String token,
			@PathVariable("name") String name) {
		log.debug("Inside NetworthController GetProtofiolio method is runnig");
		PortFolioDetails portFolio = portFolioService.getAll(token, name);
		return portFolio;
	}
}
