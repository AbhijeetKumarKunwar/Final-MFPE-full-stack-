package com.congnizant.mfp.calculateNetWorth.service;

import com.congnizant.mfp.calculateNetWorth.model.AssetSaleResponse;
import com.congnizant.mfp.calculateNetWorth.model.CalculateReaponse;
import com.congnizant.mfp.calculateNetWorth.model.PortFolioDetails;

public interface PortFolioService  {

	public PortFolioDetails findById(String id);
	
	public void savePortFolio(PortFolioDetails p);
	
	public CalculateReaponse calculateNetworth(String token, String portFolioId);
	
	public AssetSaleResponse sell(String token, PortFolioDetails portFolio);
	
	public PortFolioDetails getAll(String token,String name);
	
}
