package com.congnizant.mfp.calculateNetWorth.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="mutual_fund")
public class MutualFundDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="mutual_id")
	private int mutualId;
	@Column(name="mutual_fund_name")
	private String mutualFundName;
	@Column(name="mutual_fund_unit")
	private int mutualFundUnits ;
	@ManyToOne
	@JoinColumn(name="pid")
	private PortFolioDetails portFolio;
}
