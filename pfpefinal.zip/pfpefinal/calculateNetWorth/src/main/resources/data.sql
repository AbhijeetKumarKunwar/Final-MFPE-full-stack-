insert into portofolio(id,name) values ('ashish','ashish');
insert into portofolio(id,name) values ('abhijeet','abhijeet');

insert into stock_details(stock_id,stock_name,stock_count,pid) values (101,'Apple',50,'ashish');
insert into stock_details(stock_id,stock_name,stock_count,pid) values (102,'JPMorgan Chase',40,'ashish');
insert into stock_details(stock_id,stock_name,stock_count,pid) values (104,'Johnson and Johnson',40,'ashish');

insert into stock_details(stock_id,stock_name,stock_count,pid) values (103,'Johnson and Johnson',30,'abhijeet');
insert into stock_details(stock_id,stock_name,stock_count,pid) values (105,'Apple',50,'abhijeet');
insert into stock_details(stock_id,stock_name,stock_count,pid) values (106,'JPMorgan Chase',40,'abhijeet');

insert into mutual_fund(mutual_id,mutual_fund_name,mutual_fund_unit,pid) values (101,'Kotak',80,'ashish');
insert into mutual_fund(mutual_id,mutual_fund_name,mutual_fund_unit,pid) values (102,'Axis',70,'ashish');
insert into mutual_fund(mutual_id,mutual_fund_name,mutual_fund_unit,pid) values (103,'Kotak',60,'abhijeet');
insert into mutual_fund(mutual_id,mutual_fund_name,mutual_fund_unit,pid) values (104,'Axis',70,'abhijeet');

